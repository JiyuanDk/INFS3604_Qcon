package com.example.android.infs3604_bpm_qcon;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BPM_Diagram extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bpm__diagram);
    }
}
